---
name: violations--158
description: Benchmark violation skill number 158 for FM007 testing
version: 1.0.0
triggers:
  - when working on violations skill 158
allowed-tools:
  - Read
  - Write
  - Edit
---

# Violations Skill 158

## Overview

This skill demonstrates violation pattern **FM007** for benchmark testing.
It contains realistic markdown body content so that the linter processes a
representative file size when scanning the plugin.

## Role Identification (Mandatory)

The model must identify its ROLE_TYPE before proceeding with any task.

## When to Use This Skill

Use this skill when you need to:

- Perform the primary task associated with Violations Skill 158
- Coordinate related sub-tasks across multiple agents
- Validate outputs against acceptance criteria
- Report results in a structured format

## Core Behaviour

1. Receive the task description from the orchestrator.
2. Analyse the inputs and identify required resources.
3. Execute the task using available tools.
4. Return structured results with clear success/failure indicators.

## Output Format

Results are always returned as a structured summary containing:

- Status: success or failure
- Details: human-readable explanation
- Artifacts: any files or data produced

## Notes

- Always verify inputs before processing.
- Prefer idempotent operations where possible.
- Log progress at each major step.
- This file is intentionally verbose for benchmark purposes.
